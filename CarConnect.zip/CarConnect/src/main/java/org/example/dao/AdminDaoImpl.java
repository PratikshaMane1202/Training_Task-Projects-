package org.example.dao;

import org.example.entity.Admin;
import org.example.exception.AdminNotFoundException;
import org.example.util.DBConnUtil;
import org.example.util.DBPropertyUtil;


import java.sql.*;
import java.util.Properties;

public class AdminDaoImpl implements AdminDao {
    private Connection conn;

    public AdminDaoImpl() {
        try {
            Properties props = DBPropertyUtil.loadProperties("db.properties");
            this.conn = DBConnUtil.getConnection();
        } catch (Exception e) {
            throw new RuntimeException("Failed to connect to DB: " + e.getMessage());
        }
    }

    @Override
    public Admin getAdminById(int adminId) {
        String query = "SELECT * FROM Admin WHERE AdminID = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, adminId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return mapAdmin(rs);
            } else {
                throw new AdminNotFoundException("Admin not found with ID: " + adminId);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving admin: " + e.getMessage());
        }
    }

    @Override
    public Admin getAdminByUsername(String username) {
        String query = "SELECT * FROM Admin WHERE Username = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return mapAdmin(rs);
            } else {
                throw new AdminNotFoundException("Admin not found with Username: " + username);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving admin: " + e.getMessage());
        }
    }

    @Override
    public boolean registerAdmin(Admin admin) {
        String query = "INSERT INTO Admin (FirstName, LastName, Email, PhoneNumber, Username, Password, Role, JoinDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, admin.getFirstName());
            ps.setString(2, admin.getLastName());
            ps.setString(3, admin.getEmail());
            ps.setString(4, admin.getPhoneNumber());
            ps.setString(5, admin.getUsername());
            ps.setString(6, admin.getPassword());
            ps.setString(7, admin.getRole());
            ps.setDate(8,  java.sql.Date.valueOf(admin.getJoinDate()));
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Error registering admin: " + e.getMessage());
        }
    }

    @Override
    public boolean updateAdmin(Admin admin) {
        String query = "UPDATE Admin SET FirstName = ?, LastName = ?, Email = ?, PhoneNumber = ?, Password = ?, Role = ? WHERE AdminID = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, admin.getFirstName());
            ps.setString(2, admin.getLastName());
            ps.setString(3, admin.getEmail());
            ps.setString(4, admin.getPhoneNumber());
            ps.setString(5, admin.getPassword());
            ps.setString(6, admin.getRole());
            ps.setInt(7, admin.getAdminID());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Error updating admin: " + e.getMessage());
        }
    }

    @Override
    public boolean deleteAdmin(int adminId) {
        String query = "DELETE FROM Admin WHERE AdminID = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, adminId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting admin: " + e.getMessage());
        }
    }

    private Admin mapAdmin(ResultSet rs) throws SQLException {
        Admin admin = new Admin();
        admin.setAdminID(rs.getInt("AdminID"));
        admin.setFirstName(rs.getString("FirstName"));
        admin.setLastName(rs.getString("LastName"));
        admin.setEmail(rs.getString("Email"));
        admin.setPhoneNumber(rs.getString("PhoneNumber"));
        admin.setUsername(rs.getString("Username"));
        admin.setPassword(rs.getString("Password"));
        admin.setRole(rs.getString("Role"));
        admin.setJoinDate(rs.getDate("JoinDate").toLocalDate());
        return admin;
    }
}
