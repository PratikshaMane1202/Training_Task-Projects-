package org.example.dao;

import org.example.entity.Customer;
import java.util.Optional;

public interface CustomerDao {
    Optional<Customer> getCustomerById(int customerId);
    Optional<Customer> getCustomerByUsername(String username);
    boolean registerCustomer(Customer customer);
    boolean updateCustomer(Customer customer);
    boolean deleteCustomer(int customerId);
}
