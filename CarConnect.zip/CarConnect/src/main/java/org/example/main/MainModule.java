package org.example.main;

import org.example.dao.*;
import org.example.entity.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.Scanner;

public class MainModule {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        CustomerDaoImpl customerDao = new CustomerDaoImpl();
        VehicleDaoImpl vehicleDao = new VehicleDaoImpl();
        ReservationDaoImpl reservationDao = new ReservationDaoImpl();
        AdminDaoImpl adminDao = new AdminDaoImpl();

        boolean exit = false;
        while (!exit) {
            System.out.println("\n========== Car Rental Management ==========");
            System.out.println("1. Register Customer");
            System.out.println("2. View Customer by ID");
            System.out.println("3. Register Admin");
            System.out.println("4. Add Vehicle");
            System.out.println("5. View Vehicle by ID");
            System.out.println("6. Make Reservation");
            System.out.println("7. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    Customer customer = new Customer();
                    System.out.print("First Name: ");
                    customer.setFirstName(scanner.next());
                    System.out.print("Last Name: ");
                    customer.setLastName(scanner.next());
                    System.out.print("Email: ");
                    customer.setEmail(scanner.next());
                    System.out.print("Phone Number: ");
                    customer.setPhoneNumber(scanner.next());
                    System.out.print("Address: ");
                    customer.setAddress(scanner.next());
                    System.out.print("Username: ");
                    customer.setUsername(scanner.next());
                    System.out.print("Password: ");
                    customer.setPassword(scanner.next());
                    customer.setRegistrationDate(LocalDate.now());
                    if (customerDao.registerCustomer(customer)) {
                        System.out.println("✅ Customer registered successfully.");
                    }
                    break;

                case 2:
                    System.out.print("Enter Customer ID: ");
                    int custId = scanner.nextInt();
                    Optional<Customer> fetchedCustomer = customerDao.getCustomerById(custId);
                    if (fetchedCustomer.isPresent()) {
                        Customer c = fetchedCustomer.get();
                        System.out.println("Customer: " + c.getFirstName() + " " + c.getLastName() + ", Email: " + c.getEmail());
                    } else {
                        System.out.println("❌ Customer not found.");
                    }
                    break;

                case 3:
                    Admin admin = new Admin();
                    System.out.print("First Name: ");
                    admin.setFirstName(scanner.next());
                    System.out.print("Last Name: ");
                    admin.setLastName(scanner.next());
                    System.out.print("Email: ");
                    admin.setEmail(scanner.next());
                    System.out.print("Phone Number: ");
                    admin.setPhoneNumber(scanner.next());
                    System.out.print("Username: ");
                    admin.setUsername(scanner.next());
                    System.out.print("Password: ");
                    admin.setPassword(scanner.next());
                    System.out.print("Role: ");
                    admin.setRole(scanner.next());
                    admin.setJoinDate(LocalDate.now());
                    if (adminDao.registerAdmin(admin)) {
                        System.out.println("✅ Admin registered successfully.");
                    }
                    break;

                case 4:
                    Vehicle vehicle = new Vehicle();
                    System.out.print("Model: ");
                    vehicle.setModel(scanner.next());
                    System.out.print("Make: ");
                    vehicle.setMake(scanner.next());
                    System.out.print("Year: ");
                    vehicle.setYear(scanner.nextInt());
                    System.out.print("Color: ");
                    vehicle.setColor(scanner.next());
                    System.out.print("Registration Number: ");
                    vehicle.setRegistrationNumber(scanner.next());
                    System.out.print("Availability (true/false): ");
                    vehicle.setAvailability(scanner.nextBoolean());
                    System.out.print("Daily Rate: ");
                    vehicle.setDailyRate(scanner.nextDouble());
                    if (vehicleDao.addVehicle(vehicle)) {
                        System.out.println("✅ Vehicle added successfully.");
                    }
                    break;

                case 5:
                    System.out.print("Enter Vehicle ID: ");
                    int vid = scanner.nextInt();
                    Vehicle fetchedVehicle = vehicleDao.getVehicleById(vid);
                    if (fetchedVehicle != null) {
                        System.out.println("Vehicle: " + fetchedVehicle.getMake() + " " + fetchedVehicle.getModel());
                    } else {
                        System.out.println("❌ Vehicle not found.");
                    }
                    break;

                case 6:
                    Reservation reservation = new Reservation();
                    System.out.print("Customer ID: ");
                    reservation.setCustomerID(scanner.nextInt());
                    System.out.print("Vehicle ID: ");
                    reservation.setVehicleID(scanner.nextInt());

                    scanner.nextLine(); // Clear newline
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

                    System.out.print("Start Date (yyyy-MM-dd HH:mm:ss): ");
                    String startInput = scanner.nextLine();
                    reservation.setStartDate(LocalDateTime.parse(startInput, formatter));

                    System.out.print("End Date (yyyy-MM-dd HH:mm:ss): ");
                    String endInput = scanner.nextLine();
                    reservation.setEndDate(LocalDateTime.parse(endInput, formatter));

                    reservation.setTotalCost(reservation.calculateTotalCost(vehicleDao));
                    reservation.setStatus("Pending");

                    if (reservationDao.createReservation(reservation)) {
                        System.out.println("✅ Reservation created successfully.");
                    }
                    break;

                case 7:
                    exit = true;
                    System.out.println("👋 Exiting system. Thank you!");
                    break;

                default:
                    System.out.println("❌ Invalid choice.");
            }
        }

        scanner.close();
    }
}
