package org.example.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnUtil {

    public static Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 🔐 Local variable for the connection string
            String connectionString = "jdbc:mysql://localhost:3306/CarConnect?useSSL=false";
            String username = "root"; // replace with your DB username
            String password = "Hexaware@12345"; // replace with your DB password

            connection = DriverManager.getConnection(connectionString, username, password);
            System.out.println("✅ Database connected successfully.");
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("❌ Error while connecting to the database: " + e.getMessage());
        }
        return connection;
    }
}
