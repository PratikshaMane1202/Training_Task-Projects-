package org.example.dao;

import org.example.dao.ReservationDao;
import org.example.entity.Reservation;
import org.example.util.DBConnUtil;
import org.example.exception.ReservationException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReservationDaoImpl implements ReservationDao {

    private final Connection conn;

    public ReservationDaoImpl() {
        this.conn = DBConnUtil.getConnection();
    }

    @Override
    public Reservation getReservationById(int reservationId) {
        try {
            String query = "SELECT * FROM Reservation WHERE ReservationID = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, reservationId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return extractReservationFromResultSet(rs);
            }
        } catch (SQLException e) {
            throw new ReservationException("Failed to get reservation by ID", e);
        }
        return null;
    }

    @Override
    public List<Reservation> getReservationsByCustomerId(int customerId) {
        List<Reservation> reservations = new ArrayList<>();
        try {
            String query = "SELECT * FROM Reservation WHERE CustomerID = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, customerId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                reservations.add(extractReservationFromResultSet(rs));
            }
        } catch (SQLException e) {
            throw new ReservationException("Failed to get reservations for customer ID: " + customerId, e);
        }
        return reservations;
    }

    @Override
    public boolean createReservation(Reservation reservation) {
        try {
            String query = "INSERT INTO Reservation (CustomerID, VehicleID, StartDate, EndDate, TotalCost, Status) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, reservation.getCustomerID());
            pstmt.setInt(2, reservation.getVehicleID());
            pstmt.setTimestamp(3, Timestamp.valueOf(reservation.getStartDate()));
            pstmt.setTimestamp(4, Timestamp.valueOf(reservation.getEndDate()));
            pstmt.setDouble(5, reservation.getTotalCost());
            pstmt.setString(6, reservation.getStatus());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new ReservationException("Failed to create reservation", e);
        }
    }

    @Override
    public boolean updateReservation(Reservation reservation) {
        try {
            String query = "UPDATE Reservation SET StartDate=?, EndDate=?, TotalCost=?, Status=? WHERE ReservationID=?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setTimestamp(1, Timestamp.valueOf(reservation.getStartDate()));
            pstmt.setTimestamp(2, Timestamp.valueOf(reservation.getEndDate()));
            pstmt.setDouble(3, reservation.getTotalCost());
            pstmt.setString(4, reservation.getStatus());
            pstmt.setInt(5, reservation.getReservationID());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new ReservationException("Failed to update reservation", e);
        }
    }

    @Override
    public boolean cancelReservation(int reservationId) {
        try {
            String query = "UPDATE Reservation SET Status='Cancelled' WHERE ReservationID=?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, reservationId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new ReservationException("Failed to cancel reservation", e);
        }
    }

    private Reservation extractReservationFromResultSet(ResultSet rs) throws SQLException {
        Reservation reservation = new Reservation();
        reservation.setReservationID(rs.getInt("ReservationID"));
        reservation.setCustomerID(rs.getInt("CustomerID"));
        reservation.setVehicleID(rs.getInt("VehicleID"));
        reservation.setStartDate(rs.getTimestamp("StartDate").toLocalDateTime());
        reservation.setEndDate(rs.getTimestamp("EndDate").toLocalDateTime());
        reservation.setTotalCost(rs.getDouble("TotalCost"));
        reservation.setStatus(rs.getString("Status"));
        return reservation;
    }
}
