package org.example.dao;

import org.example.entity.Vehicle;
import java.util.List;

public interface VehicleDao {
    Vehicle getVehicleById(int vehicleId);
    List<Vehicle> getAvailableVehicles();
    boolean addVehicle(Vehicle vehicle);
    boolean updateVehicle(Vehicle vehicle);
    void removeVehicle(int vehicleId);

    List<Vehicle> getAllVehicles();
}
