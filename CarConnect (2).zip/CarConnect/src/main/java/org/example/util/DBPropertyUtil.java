package org.example.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil {


    public static Properties loadProperties(String fileName) {
        Properties props = new Properties();

        try (InputStream input = DBPropertyUtil.class.getClassLoader().getResourceAsStream(fileName)) {
            if (input == null) {
                throw new RuntimeException(fileName + " file not found in classpath");
            }
            props.load(input);
        } catch (IOException e) {
            throw new RuntimeException("Error loading properties from file: " + fileName, e);
        }

        return props;
    }


    public static String getConnectionString(String fileName) {
        Properties props = loadProperties("db.properties");

        String url = props.getProperty("db.url");
        String user = props.getProperty("db.username");
        String pass = props.getProperty("db.password");

        return url + "?user=" + user + "&password=" + pass;
    }
}
