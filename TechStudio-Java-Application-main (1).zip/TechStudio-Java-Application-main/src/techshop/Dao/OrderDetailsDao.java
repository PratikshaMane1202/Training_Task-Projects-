package techshop.Dao;

import techshop.model.OrderDetails;
import techshop.model.Product;
import techshop.model.Orders;
import techshop.util.DatabaseConnector;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDetailsDao {

    private ProductDao productDAO = new ProductDao();
    private OrderDao orderDAO = new OrderDao();

    // Add Order Detail
    public void addOrderDetail(OrderDetails detail) throws SQLException {
        String sql = "INSERT INTO OrderDetails (OrderID, ProducdID, quantity, discount) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, detail.getOrder().getOrderID());
            stmt.setInt(2, detail.getProduct().getProductID());
            stmt.setInt(3, detail.getQuantity());
            stmt.setDouble(4, detail.getDiscount());
            stmt.executeUpdate();
        }
    }

    // Get OrderDetails by Order ID
    public List<OrderDetails> getOrderDetailsByOrderId(int orderId) throws SQLException {
        List<OrderDetails> details = new ArrayList<>();
        String sql = "SELECT * FROM OrderDetails WHERE OrderID = ?";

        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int detailId = rs.getInt("order_detail_id");
                int productId = rs.getInt("product_id");
                int quantity = rs.getInt("quantity");
                double discount = rs.getDouble("discount");

                Product product = productDAO.getProductById(productId);
                Orders order = orderDAO.getOrderById(orderId);

                OrderDetails detail = new OrderDetails(detailId, order, product, quantity);
                detail.setDiscount(discount);

                details.add(detail);
            }
        }
        return details;
    }

    // Update OrderDetail
    public void updateOrderDetail(OrderDetails detail) throws SQLException {
        String sql = "UPDATE OrderDetails SET ProductID=?, quantity=?, discount=? WHERE OrderDetailID=?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, detail.getProduct().getProductID());
            stmt.setInt(2, detail.getQuantity());
            stmt.setDouble(3, detail.getDiscount());
            stmt.setInt(4, detail.getOrderDetailID());
            stmt.executeUpdate();
        }
    }

    // Delete OrderDetail
    public void deleteOrderDetail(int detailId) throws SQLException {
        String sql = "DELETE FROM OrderDetails WHERE OrderDetailID=?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, detailId);
            stmt.executeUpdate();
        }
    }

    // Get all OrderDetails
    public List<OrderDetails> getAllOrderDetails() throws SQLException {
        List<OrderDetails> details = new ArrayList<>();
        String sql = "SELECT * FROM OrderDetails";

        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int detailId = rs.getInt("order_detail_id");
                int orderId = rs.getInt("order_id");
                int productId = rs.getInt("product_id");
                int quantity = rs.getInt("quantity");
                double discount = rs.getDouble("discount");

                Product product = productDAO.getProductById(productId);
                Orders order = orderDAO.getOrderById(orderId);

                OrderDetails detail = new OrderDetails(detailId, order, product, quantity);
                detail.setDiscount(discount);

                details.add(detail);
            }
        }
        return details;
    }
}
