package techshop.Dao;

import techshop.model.Inventory;
import techshop.model.Product;
import techshop.util.DatabaseConnector;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class InventoryDao {

    private final ProductDao productDAO = new ProductDao();

    // Add Inventory Record
    public void addInventory(Inventory inventory) throws SQLException {
        String sql = "INSERT INTO Inventory (ProductID, QuantityInStock, LastStockUpdate) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, inventory.getProduct().getProductID());
            stmt.setInt(2, inventory.getQuantityInStock());
            stmt.setDate(3, Date.valueOf(inventory.getLastStockUpdate()));
            stmt.executeUpdate();
        }
    }

    // Get Inventory by InventoryID
    public Inventory getInventoryById(int inventoryId) throws SQLException {
        String sql = "SELECT * FROM Inventory WHERE InventoryID = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, inventoryId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int productId = rs.getInt("ProductID");
                Product product = productDAO.getProductById(productId);

                Inventory inventory = new Inventory(
                        rs.getInt("InventoryID"),
                        product,
                        rs.getInt("QuantityInStock")
                );
                inventory.setLastStockUpdate(rs.getDate("LastStockUpdate").toLocalDate());

                return inventory;
            }
        }
        return null;
    }

    // Get Inventory by ProductID
    public Inventory getInventoryByProductId(int productId) throws SQLException {
        String sql = "SELECT * FROM Inventory WHERE ProductID = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Product product = productDAO.getProductById(productId);

                Inventory inventory = new Inventory(
                        rs.getInt("InventoryID"),
                        product,
                        rs.getInt("QuantityInStock")
                );
                inventory.setLastStockUpdate(rs.getDate("LastStockUpdate").toLocalDate());

                return inventory;
            }
        }
        return null;
    }

    // Update Inventory Record
    public void updateInventory(Inventory inventory) throws SQLException {
        String sql = "UPDATE Inventory SET ProductID = ?, QuantityInStock = ?, LastStockUpdate = ? WHERE InventoryID = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, inventory.getProduct().getProductID());
            stmt.setInt(2, inventory.getQuantityInStock());
            stmt.setDate(3, Date.valueOf(inventory.getLastStockUpdate()));
            stmt.setInt(4, inventory.getInventoryID());
            stmt.executeUpdate();
        }
    }

    // Delete Inventory Record
    public void deleteInventory(int inventoryId) throws SQLException {
        String sql = "DELETE FROM Inventory WHERE InventoryID = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, inventoryId);
            stmt.executeUpdate();
        }
    }
    public List<Inventory> getLowStockProducts(int threshold) throws SQLException {
        List<Inventory> lowStockList = new ArrayList<>();
        String query = "SELECT * FROM inventory WHERE QuantityInStock < ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, threshold);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Inventory inventory = new Inventory(
                        rs.getInt("inventory_id"),
                        new Product(rs.getInt("product_id"), "", "", 0), // Load full product if needed
                        rs.getInt("quantity_in_stock")
                );
                lowStockList.add(inventory);
            }
        }
        return lowStockList;
    }

    // Get All Inventory Records
    public List<Inventory> getAllInventory() throws SQLException {
        List<Inventory> inventoryList = new ArrayList<>();
        String sql = "SELECT * FROM Inventory";

        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int inventoryId = rs.getInt("InventoryID");
                int productId = rs.getInt("ProductID");
                int quantity = rs.getInt("QuantityInStock");
                LocalDate lastUpdated = rs.getDate("LastStockUpdate").toLocalDate();

                Product product = productDAO.getProductById(productId);
                Inventory inventory = new Inventory(inventoryId, product, quantity);
                inventory.setLastStockUpdate(lastUpdated);

                inventoryList.add(inventory);
            }
        }
        return inventoryList;
    }
}
