package techshop.model;
import techshop.exception.InvalidDataException;


public class Customer {
    private int customerID;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String address;

    public Customer(int customerID, String firstName, String lastName, String email, String phone, String address) {
        this.customerID = customerID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.address = address;
    }

    public Customer() {
        // Default constructor
    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public void setEmail(String email) throws InvalidDataException {
        if (email == null || !email.contains("@")) {
            throw new InvalidDataException("Invalid email address format.");
        }
        this.email = email;
    }


    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setCustomerId(int customerId) {
        this.customerID = customerID;
    }


    public void setAddress(String address) {
        this.address = address;
    }

    // Calculates total number of orders (dummy logic for now)
    public int calculateTotalOrders() {
        return 0; // Placeholder, actual logic would pull from DB
    }

    // Display detailed customer info
    public void getCustomerDetails() {
        System.out.println("Customer ID: " + customerID);
        System.out.println("Name: " + firstName + " " + lastName);
        System.out.println("Email: " + email);
        System.out.println("Phone: " + phone);
        System.out.println("Address: " + address);
    }

    // Update customer info
    public void updateCustomerInfo(String email, String phone, String address) throws InvalidDataException {
        setEmail(email); // This might throw InvalidDataException
        setPhone(phone);
        setAddress(address);
    }

}

