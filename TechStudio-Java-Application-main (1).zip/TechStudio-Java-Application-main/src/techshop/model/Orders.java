package techshop.model;

import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

public class Orders {
    private int OrderID;
    private Customer customer;
    private LocalDate orderDate;
    private double totalAmount;
    private String orderStatus;
    private List<OrderDetails> orderDetailsList;

    // ✅ Constructor for detailed usage (with Customer object)
    public Orders(int orderID, Customer customer, LocalDate orderDate, String orderStatus) {
        this.OrderID = orderID;
        this.customer = customer;
        this.orderDate = orderDate;
        this.orderStatus = orderStatus;
        this.orderDetailsList = new ArrayList<>();
        this.totalAmount = 0.0;
    }

    // ✅ Constructor for basic DAO use (with customerId only)
    public Orders(int orderID, int customerID, LocalDate orderDate, String orderStatus, double totalAmount) {
        this.OrderID = orderID;
        this.customer = new Customer();
        this.customer.setCustomerID(customerID);
        this.orderDate = orderDate;
        this.orderStatus = orderStatus;
        this.totalAmount = totalAmount;
        this.orderDetailsList = new ArrayList<>();
    }

    // ✅ Add order detail and update total
    public void addOrderDetail(OrderDetails detail) {
        orderDetailsList.add(detail);
        calculateTotalAmount();
    }

    // ✅ Recalculate total from all order details
    public void calculateTotalAmount() {
        totalAmount = 0;
        for (OrderDetails detail : orderDetailsList) {
            totalAmount += detail.calculateSubtotal();
        }
    }

    // ✅ Print order details to console
    public void getOrderDetails() {
        System.out.println("Order ID: " + OrderID);
        System.out.println("Customer: " + customer.getFirstName() + " " + customer.getLastName());
        System.out.println("Order Date: " + orderDate);
        System.out.println("Status: " + orderStatus);
        System.out.println("Order Items:");
        for (OrderDetails detail : orderDetailsList) {
            detail.getOrderDetailInfo();
        }
        System.out.println("Total Amount: ₹" + totalAmount);
    }

    // ✅ Update order status
    public void updateOrderStatus(String newStatus) {
        this.orderStatus = newStatus;
        System.out.println("Order status updated to: " + newStatus);
    }

    // ✅ Cancel order
    public void cancelOrder() {
        this.orderStatus = "Cancelled";
        for (OrderDetails detail : orderDetailsList) {
            Product product = detail.getProduct();
            int quantity = detail.getQuantity();
            System.out.println("Restocking " + quantity + " units of product: " + product.getProductName());
            // Example: inventory.addToInventory(quantity); // Implement in InventoryManager
        }
        System.out.println("Order has been cancelled.");
    }

    // ✅ Getter for customer ID
    public int getCustomerId() {
        return customer != null ? customer.getCustomerID() : -1;
    }

    // ✅ Setter for customer ID
    public void setCustomerId(int id) {
        if (customer == null) {
            customer = new Customer();
        }
        customer.setCustomerID(id);
    }

    // ✅ Getter for order date (alias)
    public LocalDate getTime() {
        return this.orderDate;
    }

    // ✅ Alias for order status
    public String getStatus() {
        return this.orderStatus;
    }

    // ✅ Setter for order ID
    public void setOrderID(int orderID) {
        this.OrderID = orderID;
    }

    // ✅ Getter for order ID
    public int getOrderID() {
        return OrderID;
    }

    public Customer getCustomer() {
        return customer;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public List<OrderDetails> getOrderDetailsList() {
        return orderDetailsList;
    }
}
