package techshop.test;

import java.sql.Connection;
import techshop.util.DatabaseConnector;

public class TestConnection {
    public static void main(String[] args) {
        try (Connection conn = DatabaseConnector.getConnection()) {
            if (conn != null) {
                System.out.println("✅ Connection successful!");
            } else {
                System.out.println("❌ Connection failed!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
