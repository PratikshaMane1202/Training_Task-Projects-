package techshop.util;

import techshop.model.Inventory;
import java.util.*;

public class InventoryManager {
    private SortedMap<Integer, Inventory> inventoryMap = new TreeMap<>();

    public void addOrUpdateInventory(Inventory inventory) {
        inventoryMap.put(inventory.getProduct().getProductID(), inventory);
    }

    public Inventory getInventoryByProductId(int productId) {
        return inventoryMap.get(productId);
    }

    public void removeInventory(int productId) {
        inventoryMap.remove(productId);
    }

    public List<Inventory> listLowStock(int threshold) {
        List<Inventory> result = new ArrayList<>();
        for (Inventory inv : inventoryMap.values()) {
            if (inv.getQuantityInStock() < threshold) {
                result.add(inv);
            }
        }
        return result;
    }

    public List<Inventory> listOutOfStock() {
        List<Inventory> result = new ArrayList<>();
        for (Inventory inv : inventoryMap.values()) {
            if (inv.getQuantityInStock() == 0) {
                result.add(inv);
            }
        }
        return result;
    }

    public Collection<Inventory> getAllInventory() {
        return inventoryMap.values();
    }
}
