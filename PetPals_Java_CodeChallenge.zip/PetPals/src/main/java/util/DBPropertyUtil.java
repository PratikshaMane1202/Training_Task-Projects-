package util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil {
    public static String getConnectionString(String propertyFileName) throws IOException {
        Properties properties = new Properties();
        try (InputStream input = DBPropertyUtil.class.getClassLoader().getResourceAsStream(propertyFileName)) {
            if (input == null) {
                throw new IOException("Unable to find " + propertyFileName + " in resources");
            }
            properties.load(input);
            return properties.getProperty("db.url") + "?user=" + properties.getProperty("db.username") +
                    "&password=" + properties.getProperty("db.password");
        }
    }
}