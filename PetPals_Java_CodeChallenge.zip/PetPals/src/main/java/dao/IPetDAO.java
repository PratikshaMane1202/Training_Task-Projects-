package dao;

import entity.Pet;

import java.util.List;

public interface IPetDAO {
    void addPet(Pet pet) throws Exception;
    void removePet(int petId) throws Exception;
    List<Pet> listAvailablePets();
}
