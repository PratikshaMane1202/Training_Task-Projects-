package dao;

public interface IAdoptable {
    void adopt();
}
