package dao;

import entity.CashDonation;
import entity.Cat;
import entity.Dog;
import entity.Pet;
import exception.AdoptionException;
import util.DBConnUtil;
import util.DBPropertyUtil;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PetDAOImpl implements IPetDAO {
    private final Connection connection;

    public PetDAOImpl() throws SQLException, IOException {
        String connString = DBPropertyUtil.getConnectionString("db.properties");
        if (connString == null) {
            throw new SQLException("Failed to retrieve connection string from properties file");
        }
        this.connection = DBConnUtil.getConnection(connString);
        if (this.connection == null) {
            throw new SQLException("Failed to establish database connection");
        }
    }

    @Override
    public void addPet(Pet pet) throws Exception {
        String sql = "INSERT INTO Pet (id, name, age, breed, adopted) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, pet.getId());
            stmt.setString(2, pet.getName());
            stmt.setInt(3, pet.getAge());
            stmt.setString(4, pet.getBreed());
            stmt.setBoolean(5, pet.isAdopted());
            stmt.executeUpdate();

            if (pet instanceof Dog) {
                Dog dog = (Dog) pet;
                String dogSql = "INSERT INTO Dog (pet_id, dog_breed) VALUES (?, ?)";
                try (PreparedStatement dogStmt = connection.prepareStatement(dogSql)) {
                    dogStmt.setInt(1, dog.getId());
                    dogStmt.setString(2, dog.getDogBreed());
                    dogStmt.executeUpdate();
                }
            } else if (pet instanceof Cat) {
                Cat cat = (Cat) pet;
                String catSql = "INSERT INTO Cat (pet_id, cat_color) VALUES (?, ?)";
                try (PreparedStatement catStmt = connection.prepareStatement(catSql)) {
                    catStmt.setInt(1, cat.getId());
                    catStmt.setString(2, cat.getCatColor());
                    catStmt.executeUpdate();
                }
            }

            String shelterSql = "INSERT INTO PetShelter (pet_id) VALUES (?)";
            try (PreparedStatement shelterStmt = connection.prepareStatement(shelterSql)) {
                shelterStmt.setInt(1, pet.getId());
                shelterStmt.executeUpdate();
            }
        }
    }

    @Override
    public void removePet(int petId) throws Exception {
        if (connection == null) {
            throw new SQLException("Database connection is null");
        }

        connection.setAutoCommit(false); // Start transaction
        try {
            // Delete from cat table first (if it exists for this pet_id)
            String catSql = "DELETE FROM Cat WHERE pet_id = ?";
            try (PreparedStatement catStmt = connection.prepareStatement(catSql)) {
                catStmt.setInt(1, petId);
                catStmt.executeUpdate();
            }

            // Delete from dog table (if it exists for this pet_id)
            String dogSql = "DELETE FROM Dog WHERE pet_id = ?";
            try (PreparedStatement dogStmt = connection.prepareStatement(dogSql)) {
                dogStmt.setInt(1, petId);
                dogStmt.executeUpdate();
            }

            // Delete from petshelter table (if it exists for this pet_id)
            String shelterSql = "DELETE FROM PetShelter WHERE pet_id = ?";
            try (PreparedStatement shelterStmt = connection.prepareStatement(shelterSql)) {
                shelterStmt.setInt(1, petId);
                shelterStmt.executeUpdate();
            }

            // Finally, delete from pet table
            String petSql = "DELETE FROM Pet WHERE id = ?";
            try (PreparedStatement petStmt = connection.prepareStatement(petSql)) {
                petStmt.setInt(1, petId);
                int rowsAffected = petStmt.executeUpdate();
                if (rowsAffected == 0) {
                    throw new Exception("No pet found with ID " + petId + " to remove.");
                }
            }

            connection.commit(); // Commit transaction
        } catch (SQLException e) {
            connection.rollback(); // Rollback on error
            throw new SQLException("Failed to remove pet with ID " + petId + ": " + e.getMessage(), e);
        } finally {
            connection.setAutoCommit(true); // Reset auto-commit
        }
    }

    @Override
    public List<Pet> listAvailablePets() {
        List<Pet> pets = new ArrayList<>();
        String sql = "SELECT p.id, p.name, p.age, p.breed, p.adopted, d.dog_breed, c.cat_color " +
                "FROM Pet p " +
                "LEFT JOIN Dog d ON p.id = d.pet_id " +
                "LEFT JOIN Cat c ON p.id = c.pet_id " +
                "WHERE p.adopted = false";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int age = rs.getInt("age");
                String breed = rs.getString("breed");
                boolean adopted = rs.getBoolean("adopted");
                String dogBreed = rs.getString("dog_breed");
                String catColor = rs.getString("cat_color");

                if (dogBreed != null) {
                    pets.add(new Dog(id, name, age, breed, adopted, dogBreed));
                } else if (catColor != null) {
                    pets.add(new Cat(id, name, age, breed, adopted, catColor));
                } else {
                    pets.add(new Pet(id, name, age, breed, adopted));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pets;
    }

    public void adoptPet(int petId) throws SQLException, AdoptionException {
        if (connection == null) {
            throw new SQLException("Database connection is null");
        }

        connection.setAutoCommit(false); // Start transaction
        try {
            String checkSql = "SELECT name, age, breed, adopted FROM Pet WHERE id = ?";
            try (PreparedStatement checkStmt = connection.prepareStatement(checkSql)) {
                checkStmt.setInt(1, petId);
                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (!rs.next()) {
                        throw new AdoptionException("Pet with ID " + petId + " does not exist.");
                    }
                    String name = rs.getString("name");
                    int age = rs.getInt("age");
                    String breed = rs.getString("breed");
                    boolean adopted = rs.getBoolean("adopted");

                    if (name == null || name.trim().isEmpty()) {
                        throw new AdoptionException("Cannot adopt pet with ID " + petId + ": Name is missing.");
                    }
                    if (age <= 0) {
                        throw new AdoptionException("Cannot adopt pet with ID " + petId + ": Invalid age.");
                    }
                    if (breed == null || breed.trim().isEmpty()) {
                        throw new AdoptionException("Cannot adopt pet with ID " + petId + ": Breed is missing.");
                    }
                    if (adopted) {
                        throw new AdoptionException("Pet with ID " + petId + " is already adopted.");
                    }
                }
            }

            String updateSql = "UPDATE Pet SET adopted = true WHERE id = ?";
            try (PreparedStatement updateStmt = connection.prepareStatement(updateSql)) {
                updateStmt.setInt(1, petId);
                int rowsAffected = updateStmt.executeUpdate();
                if (rowsAffected == 0) {
                    throw new AdoptionException("Failed to adopt pet with ID " + petId + ": No rows updated.");
                }
            }

            connection.commit(); // Commit transaction
        } catch (SQLException e) {
            connection.rollback(); // Rollback on error
            throw new SQLException("Database error in adoptPet: " + e.getMessage(), e);
        } catch (AdoptionException e) {
            connection.rollback(); // Rollback on adoption error
            throw e;
        } finally {
            connection.setAutoCommit(true); // Reset auto-commit
        }
    }

    public void recordCashDonation(CashDonation donation) throws SQLException {
        if (connection == null) {
            throw new SQLException("Database connection is null");
        }
        if (donation == null || donation.getDonorName() == null || donation.getDonationDate() == null) {
            throw new SQLException("Invalid donation data: donor name or date is null");
        }

        connection.setAutoCommit(false); // Start transaction
        try {
            String checkSql = "SELECT id FROM Donation WHERE id = ?";
            try (PreparedStatement checkStmt = connection.prepareStatement(checkSql)) {
                checkStmt.setInt(1, donation.getId());
                if (checkStmt.executeQuery().next()) {
                    throw new SQLException("Donation ID " + donation.getId() + " already exists.");
                }
            }

            String donationSql = "INSERT INTO Donation (id, donor_name, amount) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(donationSql)) {
                stmt.setInt(1, donation.getId());
                stmt.setString(2, donation.getDonorName());
                stmt.setDouble(3, donation.getAmount());
                stmt.executeUpdate();
            }

            String cashSql = "INSERT INTO CashDonation (donation_id, donation_date) VALUES (?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(cashSql)) {
                stmt.setInt(1, donation.getId());
                stmt.setDate(2, java.sql.Date.valueOf(donation.getDonationDate()));
                stmt.executeUpdate();
            }

            connection.commit(); // Commit transaction
        } catch (SQLException e) {
            connection.rollback(); // Rollback on error
            throw new SQLException("Failed to record cash donation: " + e.getMessage(), e);
        } finally {
            connection.setAutoCommit(true); // Reset auto-commit
        }
    }
}